--create table CATEGORY
--(     CATCODE varchar(2)        -- we are using varchar upto maximum length
--    , CATDESC varchar(10)       -- char means it has to have a certain length
--)
--;

--create table EMPLOYEES
--(     EMP# number(5)
--    , FIRSTNAME varchar(25)
--    , LASTNAME varchar(25)
--    , JOB_CLASS varchar(4)
--)
--;

--alter table EMPLOYEES add
--(
--       EMPDATE date default SYSDATE
--     , ENDDATE date
--)
--;

--alter table EMPLOYEES
--         modify JOB_CLASS varchar(2)
--;

--alter table EMPLOYEES drop
--(
--       ENDDATE
--)
--;

--alter table EMPLOYEES
--       rename to JL_EMPS
--;

--create table BOOK_PRICING
--(
--       ID number(13)
--     , COST number(6)
--     , RETAIL number(6)
--     , CATEGORY varchar(15)
--)
--;
--
--alter table BOOK_PRICING
--       set unused (CATEGORY)
--;
--
--select CATEGORY
--from BOOK_PRICING
--;

--truncate table BOOK_PRICING;
--
--select *
--from BOOK_PRICING
--;

--drop table BOOK_PRICING;
--delete from JL_EMPS;
--rollback;
--desc JL_EMPS;

--create table STORE_REPS
--(     REP_ID_PK     number(5) primary key
--    , LAST          varchar2(15)
--    , FIRST         varchar2(10)
--    , COMM          char(1) default 'Y'
--)
--;

--alter table STORE_REPS modify
--(
--       FIRST    not null
--     , LAST     not null
--)
--;

--alter table STORE_REPS
--       add constraint COMMM
--       check ((COMM = 'Y') or (COMM = 'N'))
--;

--alter table STORE_REPS add
--(
--       BASE_SALARY      number(7,2)
--       check (BASE_SALARY > 0)
--)
--;

--create table BOOK_STORES
--(
--       STORE_ID_PK     number(9)        primary key
--     , NAME            varchar2(30) unique not null
--     , CONTACT         varchar2(30)
--     , REP_ID          varchar2(5)
--)
--;

--alter table BOOK_STORES modify
--(
--       REP_ID       number(5)       unique not null
--)
--;
    
--alter table BOOK_STORES   
--    add constraint REP_ID_FK
--       foreign key (REP_ID)
--       references STORE_REPS(REP_ID)
--    on delete cascade
--;

--create table REP_CONTRACTS 
--(
--       STORE_ID     number(5)
--      ,NAME         number(5)
--      ,QUARTER      char(4)
--      ,REP_ID       number(5)   
--      ,constraint REP_CONTRACTS_PK            primary key (REP_ID
--                                                          ,STORE_ID
--                                                          ,QUARTER)
--      ,constraint REP_CONTRACTS_REP_ID_FK     foreign key (REP_ID)
--        references BOOK_STORES (REP_ID)
--      ,constraint REP_CONTRACTS_STORE_ID_FK   foreign key (STORE_ID)
--        references  BOOK_STORES (STORE_ID)
--)
--;

select *
from USER_CONS_COLUMNS
where TABLE_NAME = 'STORE_REPS'
;