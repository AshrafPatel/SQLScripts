--insert Into ORDERS
--(
--     ORDER#
--   , CUSTOMER#
--   , ORDERDATE
--)
--
--values
--(
--     1021
--   , 1009
--   , to_date
--        ('July-20-2009', 'MMMM-DD-YYYY')
--)
--;
--
--update ORDERS
--    set SHIPZIP = 33222
--    where ORDER# = 1017
--;
--
--commit;

--insert Into ORDERS
--(
--     ORDER#
--   , CUSTOMER#
--   , ORDERDATE
--)
--
--values
--(
--     1022
--   , 2000
--   , to_date
--        ('Augu-06-2009', 'MMMM-DD-YYYY')
--)
--;

--update ORDERS
--set 
--    ORDER# = 1023
--  , CUSTOMER# = 1009
--;

--update BOOKS
--    set COST = '&COST'
--    where ISBN = '&ISBN'
--;

--rollback;

--delete from ORDERS
--    where exists
--    (
--        select *
--        from ORDERITEMS
--        where ORDERITEMS.ORDER# = ORDERS.ORDER#
--        and ORDER# = 1005
--    )
--;

--savepoint FLASHPOINT;
--delete from ORDERS
--    where ORDER# = 1005;
--    
--delete from ORDERITEMS
--    where ORDER# = 1005;

rollback to FLASHPOINT;